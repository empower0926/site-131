Sample configuration files for:
```
SystemD: ozeetyd.service
Upstart: ozeetyd.conf
OpenRC:  ozeetyd.openrc
         ozeetyd.openrcconf
CentOS:  ozeetyd.init
macOS:    org.ozeety.ozeetyd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
